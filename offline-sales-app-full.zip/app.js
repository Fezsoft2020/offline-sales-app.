
let db;
const exchangeRate = 2500; // 1 USD = 2500 Tsh

// Initialize IndexedDB
const request = indexedDB.open('SalesDB', 1);
request.onupgradeneeded = function(event) {
  db = event.target.result;
  db.createObjectStore('stock', { keyPath: 'name' });
  db.createObjectStore('sales', { autoIncrement: true });
};
request.onsuccess = function(event) {
  db = event.target.result;
  loadStock();
  loadSales();
};

// Add shipment
function addShipment() {
  const name = document.getElementById('shipmentItem').value;
  const qty = parseInt(document.getElementById('shipmentQty').value);
  const cost = parseFloat(document.getElementById('shipmentPrice').value);
  const sell = parseFloat(document.getElementById('shipmentSell').value);
  if(!name || !qty || !cost || !sell) return alert('Fill all shipment fields');

  const tx = db.transaction('stock', 'readwrite');
  const store = tx.objectStore('stock');
  const getReq = store.get(name);
  getReq.onsuccess = function() {
    let data = getReq.result;
    if(data) {
      data.qty += qty;
      data.cost = cost;
      data.sell = sell;
    } else {
      data = {name, qty, cost, sell};
    }
    store.put(data);
  };
  tx.oncomplete = () => { loadStock(); };
  document.getElementById('shipmentItem').value = '';
  document.getElementById('shipmentQty').value = '';
  document.getElementById('shipmentPrice').value = '';
  document.getElementById('shipmentSell').value = '';
}

// Load stock
function loadStock() {
  const tx = db.transaction('stock', 'readonly');
  const store = tx.objectStore('stock');
  const req = store.getAll();
  req.onsuccess = function() {
    window.stockData = req.result;
    updateStockDropdown();
    updateStockTable();
    updateDashboard();
  };
}

// Prefill selling price
function prefillSellPrice() {
  const name = document.getElementById('saleItem').value;
  const item = window.stockData.find(i => i.name === name);
  if(item) document.getElementById('salePrice').value = item.sell;
}

// Update stock dropdown
function updateStockDropdown() {
  const saleItem = document.getElementById('saleItem');
  saleItem.innerHTML = '';
  window.stockData.forEach(item => {
    const option = document.createElement('option');
    option.value = item.name;
    option.text = item.name;
    saleItem.add(option);
  });
  prefillSellPrice();
}

// Update stock table
function updateStockTable() {
  const table = document.getElementById('stockTable');
  table.innerHTML = `
    <tr>
      <th>Item</th>
      <th>Quantity</th>
      <th>Cost Price</th>
      <th>Selling Price</th>
    </tr>`;
  window.stockData.forEach(item => {
    const row = table.insertRow();
    row.insertCell(0).innerText = item.name;
    row.insertCell(1).innerText = item.qty;
    row.insertCell(2).innerText = item.cost;
    row.insertCell(3).innerText = item.sell;
    if(item.qty < 10) row.classList.add('low-stock');
  });
}

// Add sale
function addSale() {
  const staff = document.getElementById('staffName').value || 'Unknown';
  const name = document.getElementById('saleItem').value;
  const qty = parseInt(document.getElementById('saleQty').value);
  const sellPrice = parseFloat(document.getElementById('salePrice').value);
  if(!name || !qty || !sellPrice) return alert('Fill all sale fields');

  const item = window.stockData.find(i => i.name === name);
  if(!item || item.qty < qty) return alert('Not enough stock');

  const tx = db.transaction(['stock','sales'], 'readwrite');
  const stockStore = tx.objectStore('stock');
  const saleStore = tx.objectStore('sales');

  item.qty -= qty;
  stockStore.put(item);

  const saleRecord = {staff, name, qty, sellPrice, cost: item.cost, date: new Date()};
  saleStore.add(saleRecord);

  tx.oncomplete = () => { loadStock(); loadSales(); };

  document.getElementById('saleQty').value = '';
  document.getElementById('salePrice').value = '';
  document.getElementById('staffName').value = '';
}

// Load sales
function loadSales() {
  const tx = db.transaction('sales', 'readonly');
  const store = tx.objectStore('sales');
  const req = store.getAll();
  req.onsuccess = function() {
    window.salesData = req.result;
    updateDashboard();
  };
}

// Update dashboard
function updateDashboard() {
  const filter = document.getElementById('filter').value;
  let revenue = 0, profit = 0;
  const now = new Date();
  window.salesData.forEach(s => {
    const saleDate = new Date(s.date);
    let include = false;
    if(filter === 'all') include = true;
    else if(filter === 'today') include = saleDate.toDateString() === now.toDateString();
    else if(filter === 'month') include = saleDate.getMonth() === now.getMonth() && saleDate.getFullYear() === now.getFullYear();
    if(include) {
      revenue += s.qty * s.sellPrice;
      profit += s.qty * (s.sellPrice - s.cost);
    }
  });
  document.getElementById('totalRevenue').innerText = revenue.toFixed(2);
  document.getElementById('totalRevenueUSD').innerText = (revenue / exchangeRate).toFixed(2);
  document.getElementById('totalProfit').innerText = profit.toFixed(2);

  const ctx = document.getElementById('stockChart').getContext('2d');
  const labels = window.stockData.map(i => i.name);
  const data = window.stockData.map(i => i.qty);

  if(window.stockChart) window.stockChart.destroy();
  window.stockChart = new Chart(ctx, {
    type: 'bar',
    data: { labels, datasets: [{ label: 'Stock Quantity', data, backgroundColor: '#4caf50' }] },
    options: { responsive: true, scales: { y: { beginAtZero: true } } }
  });
}

// Export Excel
function exportExcel() {
  const wb = XLSX.utils.book_new();
  const wsData = [["Staff", "Item", "Qty Sold", "Sell Price", "Cost Price", "Date"]];
  window.salesData.forEach(s => wsData.push([s.staff, s.name, s.qty, s.sellPrice, s.cost, new Date(s.date).toLocaleString()]));
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  XLSX.utils.book_append_sheet(wb, ws, "Sales");
  XLSX.writeFile(wb, "sales.xlsx");
}

// Export PDF
function exportPDF() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  doc.text("Sales Records", 10, 10);
  let y = 20;
  window.salesData.forEach(s => {
    doc.text(`${s.staff} | ${s.name} | ${s.qty} | ${s.sellPrice} | ${s.cost} | ${new Date(s.date).toLocaleDateString()}`, 10, y);
    y += 10;
  });
  doc.save("sales.pdf");
}
